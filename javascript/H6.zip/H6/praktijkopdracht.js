var fotosFrame = document.getElementById("fotosFrame");
var pictureHolder = document.createElement("div");
var random = 0;
var randomNumbers = [];

createPictureHolder();
createMemoryPictues();

function createPictureHolder() {
    for (let i = 0; i < 18; i++) {
        pictureHolder = document.createElement("div");
        pictureHolder.className = "picture-holder";
        pictureHolder.id = "picture-holder" + pictureHolder[plaatje];
        fotosFrame.appendChild(pictureHolder);
    }
}

while(randomNumbers.length < 18) {
    random = Math.floor(Math.random() * 18) + 1;
    if (randomNumbers.lastIndexOf(random) == -1) {
        randomNumbers.push(random)
    }
}
function createMemoryPictues() {
    pictureHolder = document.getElementsByClassName("picture-holder");
    for (let i = 0; i < pictureHolder.length; i++) {
        memoryAfbeeldingen = document.createElement("img");
        memoryAfbeeldingen.src = "source/ninja" + [random] + ".jpg";
        memoryAfbeeldingen.id = (i);
        pictureHolder[i].appendChild(memoryAfbeeldingen);
        pictureHolder[i].addEventListener("click", function () {
            afbeeldingOnclick(this.children[0].id);
        });
    }
}
function afbeeldingOnclick(id){
    afbeeldingclick = document.getElementsByTagName("img");
    afbeeldingclick[id].style.visibility="visible";
}

function memoryMatch(id) {
    if (afbeeldingOnclick(id) ) {

    }
}
random= 0;
for(var plaatje in pictureHolder) {
    pictureHolder[plaatje].id = "pictureHolder" + randomNumbers[random];
    random++;
}




